mvn clean package
#echo "yes" | cf delete object-store 
cf push
