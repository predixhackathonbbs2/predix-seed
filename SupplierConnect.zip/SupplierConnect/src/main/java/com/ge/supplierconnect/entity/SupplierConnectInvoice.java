/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.supplierconnect.entity;

/**
 * 
 * @author predix -
 */
import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SUPPLIER_CONNECT_INVOICES database table.
 * 
 */
@Entity
@Table(name="SUPPLIER_CONNECT_INVOICES")
@NamedQuery(name="SupplierConnectInvoice.findAll", query="SELECT s FROM SupplierConnectInvoice s")
public class SupplierConnectInvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SUPPLIER_CONNECT_INVOICES_INVOICENUMBER_GENERATOR", sequenceName="SUPP_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SUPPLIER_CONNECT_INVOICES_INVOICENUMBER_GENERATOR")
	@Column(name="INVOICE_NUMBER")
	private String invoiceNumber;

	private BigDecimal amount;

	@Column(name="AVAILABLE_DISCOUNT")
	private BigDecimal availableDiscount;

	private String currency;

	@Temporal(TemporalType.DATE)
	@Column(name="DISCOUNT_DATE")
	private Date discountDate;

	private BigDecimal due;

	@Temporal(TemporalType.DATE)
	@Column(name="DUE_DATE")
	private Date dueDate;

	@Temporal(TemporalType.DATE)
	@Column(name="INVOICE_DATE")
	private Date invoiceDate;

	@Column(name="INVOICE_TYPE")
	private String invoiceType;

	@Column(name="ON_HOLD")
	private String onHold;

	@Column(name="PAYMENT_NUMBER")
	private String paymentNumber;

	@Column(name="PAYMENT_STATUS")
	private String paymentStatus;

	@Column(name="PO_NUMBER")
	private String poNumber;

	private String receipt;

	@Column(name="REMIT_TO_SUPPLIER")
	private String remitToSupplier;

	@Column(name="REMIT_TO_SUPPLIER_SITE")
	private String remitToSupplierSite;

	private String status;

	public SupplierConnectInvoice() {
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getAvailableDiscount() {
		return this.availableDiscount;
	}

	public void setAvailableDiscount(BigDecimal availableDiscount) {
		this.availableDiscount = availableDiscount;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getDiscountDate() {
		return this.discountDate;
	}

	public void setDiscountDate(Date discountDate) {
		this.discountDate = discountDate;
	}

	public BigDecimal getDue() {
		return this.due;
	}

	public void setDue(BigDecimal due) {
		this.due = due;
	}

	public Date getDueDate() {
		return this.dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceType() {
		return this.invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getOnHold() {
		return this.onHold;
	}

	public void setOnHold(String onHold) {
		this.onHold = onHold;
	}

	public String getPaymentNumber() {
		return this.paymentNumber;
	}

	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}

	public String getPaymentStatus() {
		return this.paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPoNumber() {
		return this.poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getReceipt() {
		return this.receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getRemitToSupplier() {
		return this.remitToSupplier;
	}

	public void setRemitToSupplier(String remitToSupplier) {
		this.remitToSupplier = remitToSupplier;
	}

	public String getRemitToSupplierSite() {
		return this.remitToSupplierSite;
	}

	public void setRemitToSupplierSite(String remitToSupplierSite) {
		this.remitToSupplierSite = remitToSupplierSite;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
